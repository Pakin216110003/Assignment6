function changeColor(){
	document.getElementById("p1").style.backgroundColor = 'yellow';
	document.getElementById("p2").style.backgroundColor = 'yellow';
	document.getElementById("p3").style.backgroundColor = 'yellow';
}

function append(){
	let node = document.createElement("div");
	let str = document.createTextNode("Hello ITE220!");
	node.appendChild(str);
	document.getElementById("p3").appendChild(node);
}

function showHide(){
	let el1 = document.getElementById("p1");
	if (el1.style.display === null || el1.style.display === 'none'){
		el1.style.display = 'block';
	} else {
		el1.style.display = 'none';
	}
	
	let el2 = document.getElementById("p2");
	if (el2.style.display === null || el2.style.display === 'none'){
		el2.style.display = 'block';
	} else {
		el2.style.display = 'none';
	}
	
	let el3 = document.getElementById("p3");
	if (el3.style.display === null || el3.style.display === 'none'){
		el3.style.display = 'block';
	} else {
		el3.style.display = 'none';
	}
	

}